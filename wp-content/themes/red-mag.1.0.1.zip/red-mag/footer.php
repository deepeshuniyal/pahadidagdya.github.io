<footer id="colophon" class="rsrc-footer" role="contentinfo">
  <div class="row rsrc-author-credits">
    <p class="text-center">
      <?php printf(__('Copyright &copy; %1$s | %2$s designed by Themes4WP', 'red-mag'), date("Y"), '<a href="' . esc_url('http://themes4wp.com/theme/red-mag/') . '" title="' . __( 'Free Magazine WordPress Theme', 'red-mag' ) . '">' . __( 'Red Mag', 'red-mag' ) . '</a>'); ?>   
    </p>
  </div>
</footer> 
<p id="back-top">
  <a href="#top"><span></span></a>
</p>
<!-- end main container -->
</div>
<?php wp_footer(); ?>
</body>
</html>