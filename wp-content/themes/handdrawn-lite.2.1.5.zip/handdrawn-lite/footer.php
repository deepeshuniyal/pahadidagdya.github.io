<?php

?>
                        </div>
                    </div>
                <footer id="colophon" class="site-footer">
                    <div class="row">
                            <p><?php _e( 'Handdrawn theme by ', 'handdrawn-lite' ); ?><a href="<?php echo esc_url( 'http://www.svgthemes.com/' ); ?>"><?php _e( 'svgThemes', 'handdrawn-lite' ); ?></a><?php _e( ' - Proudly powered by ', 'handdrawn-lite' ); ?><a href="<?php echo esc_url( 'https://wordpress.org/' ); ?>"><?php _e( 'WordPress', 'handdrawn-lite' ); ?></a></p>
                    </div>
                </footer><!-- footer -->
            </div><!-- End Wrapper -->
        </div>

        <?php wp_footer(); ?>
    </body>
</html>
        
        
        