﻿=== WP Macchiato ===

Tags: custom-menu, full-width-template, post-formats
Requires at least: 4.0
Tested up to: 4.3-alpha
Copyright (c) 2014 by Invictus Themes (http://invictusthemes.com/)
This Theme is distributed under the terms of the GNU GPL.

License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Macchiato is based on Underscores http://underscores.me/, (C) 2012-2014 Automattic, Inc.
===========
ABOUT THEME
WP Macchiato is a classic three column blogging theme which makes use of featured images to enhance posts on the home and archive pages. 
It is fully responsive and has some handy customization features allowing you to control the primary theme colours, as well as uploading your
own logo and choosing whether or not to show the author bio on posts. There are right and left widget areas, as well as widgets for the footer and a banner widget in the header.



For free themes support, please contact us http://invictusthemes.com/contact/


============================================
Images Copyright/License Info
============================================
 * All the graphics bundled with this theme are created by the theme author and licensed under the GNU GPL.

 * The photo used in the screenshot.png was downloaded from pixabay.com and is bound to Creative Commons Deed CC0 as stated in their Terms of Service and Privacy Policy (http://pixabay.com/en/service/terms/)
	http://pixabay.com/en/breads-foods-baked-bakery-387544/
	http://pixabay.com/en/pasta-noodles-tomato-sauce-eat-482402/
	http://pixabay.com/en/fruits-market-shop-supermarket-77946/
	http://pixabay.com/en/sushi-sushi-rolls-rice-japanese-246816/
	http://pixabay.com/en/corn-corn-on-the-cob-harvest-63061/
	
 
   License URI: http://creativecommons.org/publicdomain/zero/1.0/deed.en
 
============================================
html5shiv.js Copyright/License Info
============================================
 * HTML5 Shiv 3.7.3-pre | MIT/GPL2 Licensed


============================================
ie-responsive.min.js Copyright/License Info
============================================
 * Respond.js v1.4.2 
 * Licensed under https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

============================================
This theme uses Font Awesome for the theme icons
============================================
 * Font Awesome (http://fortawesome.github.io/Font-Awesome/icons/)
 * Copyright (c) Automattic (http://fortawesome.github.io/Font-Awesome/)
 * Available under the terms of GNU GPL.
 
 
======================================
This theme uses Bootstrap as a design tool
======================================
 * Bootstrap (http://getbootstrap.com/)
 * Copyright (c) 2011-2014 Twitter, Inc
 * Licensed under https://github.com/twbs/bootstrap/blob/master/LICENSE

Version 2.4
 - Add page layout on customizer
 - Fixed sidebar issue

Version 2.3
 - included the non-minified for all minified files

Version 2.2
 - function.php
  * add default #ffffff as background color for custumizer, line: 17-18
  * removed '' from 200 line: 23
 - header.php
  * replaced the false into '' , line: 39 and 82
 - wp-macchiato-menu.php
  * add translations, line: 2
 - style.css
  * add style on line: 707 - 709

Version 2.1
 * escaped home_url(): inc/wp-macchiato-menu.php(line 2)
 * fixes on page.php: line 23-25 and 30-32
 * fixes on page.php: line 22-22, 30-32 and 36
 * fixes on sidebar.php: line 7-18

Version 2.0
* More tag fixes
* readme.txt Theme name Corrected
* long titles and site tagline responsiveness fixes

Version 1.2
* fixes on /inc/extras.php to improve wp_title tag

Version 1.1
* fixes the appearing twice if title on function.php
* fixes the <div id="main-container"class="container"> "The no space between two html attributes" on funtion.php

Version 1.0
* First public release


