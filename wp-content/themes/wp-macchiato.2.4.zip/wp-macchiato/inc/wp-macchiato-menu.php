<ul class="nav navbar-nav">					
	<li class="current_page_item"><a href="<?php echo esc_url(home_url( '/' )); ?>wp-admin/nav-menus.php"><?php _e('Set Up Your Menu' ,'wp-macchiato'); ?></a></li>
</ul>