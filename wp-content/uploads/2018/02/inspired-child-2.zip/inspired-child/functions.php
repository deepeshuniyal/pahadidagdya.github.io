<?php
/**
 * @package Inspired - Multipurpose Corporate and Creative WordPress Theme
 * @author CTHthemes - http://themeforest.net/user/cththemes
 * @date: 26-09-2016
 * @version: 1.0
 * @copyright  Copyright ( C ) 2015 cththemes.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */
// Your php code goes here




?>