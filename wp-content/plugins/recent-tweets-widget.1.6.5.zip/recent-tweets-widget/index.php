<?php
# Silence is golden.
?>